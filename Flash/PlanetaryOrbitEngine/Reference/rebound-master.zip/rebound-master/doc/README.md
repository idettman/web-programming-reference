To create a documentation that corresponds to the currently selected list of modules, type

    make doc

in any problem directory. You do need `doxygen` (http://www.stack.nl/~dimitri/doxygen/) to generate the documentation and `dot` (http://www.graphviz.org/) to generate the call and dependency graphs.
