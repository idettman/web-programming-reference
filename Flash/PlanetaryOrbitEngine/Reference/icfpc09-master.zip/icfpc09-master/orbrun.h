#include <stdio.h>
#include "orbit.h"

/* progfile tracefile humanp => | stdout */
void orb_run(FILE *, FILE *, int);
